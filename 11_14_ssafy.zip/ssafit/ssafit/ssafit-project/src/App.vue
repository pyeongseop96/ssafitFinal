<script setup>
import {RouterLink, RouterView} from 'vue-router'
import TheHeaderNav from './components/common/TheHeaderNav.vue';
</script>

<template>
  <div>
      <TheHeaderNav/>
      <RouterView/>
  </div>
</template>

<style  scoped>

</style>