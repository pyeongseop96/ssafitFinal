<template>
    <div>
        <h2>HomeView</h2>
    </div>
</template>

<script setup>
    import {RouterView} from 'vue-router'
</script>

<template>
  <div>
    <h2>홈</h2>
    <RouterView/>
  </div>
</template>


<style>


</style>