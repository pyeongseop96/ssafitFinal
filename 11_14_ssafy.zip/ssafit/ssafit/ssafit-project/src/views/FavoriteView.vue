<script setup>
    import {RouterView} from 'vue-router'
</script>

<template>
  <div>
    <h2>찜</h2>
    <RouterView/>
  </div>
</template>


<style>


</style>