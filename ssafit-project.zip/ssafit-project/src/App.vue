<template>
  <div>
      <THeHeaderNav />
      <RouterView></RouterView>
  </div>
</template>

<script setup>
import TheHeaderNav from "./components/common/TheHeaderNav.vue";
import ReviewView from "./views/ReviewView.vue";


</script>

<style  scoped></style>