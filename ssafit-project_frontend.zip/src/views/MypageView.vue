<template>
    <div>
        <MypageNav/>
        <p>마이페이지입니다....</p>
        <RouterView/>
    </div>
</template>

<script setup>
import MypageNav from '../components/mypage/MypageNav.vue';
</script>



<style scoped>

</style>