<script setup>
import KakaoMap from '../components/api/KakaoMap.vue';

</script>

<template>
  <div>
    <h2>카카오맵</h2>
    <KakaoMap/>
  </div>
</template>


<style>


</style>