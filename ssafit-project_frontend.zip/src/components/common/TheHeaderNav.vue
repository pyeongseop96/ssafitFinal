<template>
    <div>
        <header>
            <nav>
                <RouterLink to="/">Home</RouterLink> | 
                <RouterLink :to="{name:'list'}">비디오</RouterLink> | 
                <span v-if="userStore.user.name == ''"> <!-- userStore.loginUser.id == null -->
                    <RouterLink :to="{name:'login'}">로그인</RouterLink> | 
                    <RouterLink :to="{name:'regist'}">회원가입</RouterLink> | 
                </span>
                <span v-else>
                    <RouterLink :to="{name:'mypage'}">마이페이지</RouterLink> | 
                    <a @click="logout">로그아웃</a> | 
                </span>
                <RouterLink :to="{name:'map'}">주변 헬스장 찾기</RouterLink> | 
            </nav>
            <div v-if="userStore.user.name !== ''">
                <h4 >{{ userStore.user.name }}님 환영합니다.</h4>
            </div>
        </header>
    </div>
</template>

<script setup>
import {ref, onMounted} from 'vue';
import { useUserStore } from '../../stores/user';

const userStore = useUserStore();

const logout = () => {
    userStore.logoutUser();
    window.location.reload();
}


</script>

<style scoped>
nav {
    padding: 30px;
}
nav a {
    font-weight: bold;
    text-decoration: none;
    color: black;
}
nav a.router-link-exact-active {
    color: green;
}

</style>