import { ref, computed } from 'vue'
import { defineStore } from 'pinia'
import axios from 'axios'

const ReviewURL = 'http://localhost:8080/api-review'

export const useReviewStore = defineStore('review', () => {
  const showModal = ref(false)
  const reviews = ref([])
  const selectedYoutube = ref(null)
  const videoID = ref(1);

  const getReviewList = function () {
  

    axios.get(ReviewURL+'/reviewAll?videoID='+ videoID.value)
      .then((response) => {
      reviews.value = response.data
      })
  }

  return { reviews, selectedYoutube,  getReviewList, videoID, showModal}
})

