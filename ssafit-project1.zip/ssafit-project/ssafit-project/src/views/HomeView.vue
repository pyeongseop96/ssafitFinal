<template>
    <div>
        <h2>HomeView</h2>
    </div>
</template>

<script setup>

</script>

<style scoped>

</style>