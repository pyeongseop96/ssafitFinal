<script setup>
import FavChannelList from '../components/favorite/FavChannelList.vue';
import FavVideoList from '../components/favorite/FavVideoList.vue';

</script>

<template>
  <div>
    <h2>찜</h2>
    <FavChannelList/>
    <FavVideoList/>
  </div>
</template>


<style scoped>


</style>