<script setup>
import KakaoMap from '../components/api/KakaoMap.vue';
// import KakaoMap2 from '../components/api/KakaoMap2.vue';

</script>

<template>
  <div>
    <h2>카카오맵</h2>
    <KakaoMap/>
    <!-- <KakaoMap2/> -->
  </div>
</template>


<style scoped>
div {
  margin-left: auto;
  margin-right: auto;
  text-align: center;
}

</style>