package com.ssafit.board.model.service;

import java.util.List;

import com.ssafit.board.model.dto.Food;

public interface FoodService {

    List<Food> getFood(String DESC_KOR);

}
