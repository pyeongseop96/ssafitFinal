<template>
    <div>
        <p>프로필입니다</p>
    </div>
</template>

<script setup>

</script>



<style scoped>

</style>