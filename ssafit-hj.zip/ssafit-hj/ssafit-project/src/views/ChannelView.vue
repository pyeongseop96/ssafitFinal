<template>
    <div>
        <h3> 채널 페이지 </h3>
    </div>
    <ChannelVideoList/>
</template>

<script setup>
import ChannelVideoList from '../components/channel/ChannelVideoList.vue';

</script>

<style scoped>

</style>