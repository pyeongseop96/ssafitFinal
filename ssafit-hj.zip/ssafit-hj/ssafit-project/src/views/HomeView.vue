<template>
    <div>
        <h2>HomeView</h2>
        <RouterView />
    </div>
</template>

<script setup>


</script>

<style></style>