sql: 테이블 실행 후 DB 삽입
