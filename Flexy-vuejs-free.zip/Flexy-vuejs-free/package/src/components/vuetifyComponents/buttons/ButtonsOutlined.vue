<script setup lang="ts"></script>

<template>
  <!-- ----------------------------------------------------------------------------- -->
  <!-- Outlined -->
  <!-- ----------------------------------------------------------------------------- -->
  <div class="d-flex flex-wrap gap-2">
    <div>
      <v-btn variant="outlined" color="primary">Primary</v-btn>
    </div>
    <div>
      <v-btn variant="outlined" color="secondary">Secondary</v-btn>
    </div>
    <div>
      <v-btn variant="outlined" color="error">Error</v-btn>
    </div>
    <div>
      <v-btn variant="outlined" color="warning">Warning</v-btn>
    </div>
    <div>
      <v-btn variant="outlined" color="success">Success</v-btn>
    </div>
    <div>
      <v-btn variant="outlined" disabled>Disabled</v-btn>
    </div>
    <div>
      <v-btn variant="outlined">Normal</v-btn>
    </div>
  </div>
</template>
