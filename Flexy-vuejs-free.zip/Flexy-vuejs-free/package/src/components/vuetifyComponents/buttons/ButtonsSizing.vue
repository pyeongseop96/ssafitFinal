<script setup lang="ts"></script>

<template>
  <!-- ----------------------------------------------------------------------------- -->
  <!-- Size -->
  <!-- ----------------------------------------------------------------------------- -->
  <div class="d-flex flex-wrap gap-2">
      
      <div>
        <v-btn color="primary" size="x-small">Extra Small</v-btn>
      </div>
      <div>
        <v-btn color="secondary" size="small">Small</v-btn>
      </div>
      <div>
        <v-btn color="error">Normal</v-btn>
      </div>
      <div>
        <v-btn color="warning" size="large">Large</v-btn>
      </div>
      <div>
        <v-btn color="success" size="x-large">Extra Large</v-btn>
      </div>
  </div>
</template>
