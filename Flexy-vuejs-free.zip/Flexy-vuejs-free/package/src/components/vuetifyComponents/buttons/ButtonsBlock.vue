<script setup lang="ts"></script>

<template>
  <!-- ----------------------------------------------------------------------------- -->
  <!-- Block -->
  <!-- ----------------------------------------------------------------------------- -->
  <div class="d-flex gap-2 flex-wrap">
    <v-btn block color="primary">Block Button</v-btn>
    <v-btn block color="secondary">Block Button</v-btn>
  </div>
</template>
