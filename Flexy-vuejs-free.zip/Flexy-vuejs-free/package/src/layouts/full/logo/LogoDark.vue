<template>
  <div class="logo">
    <RouterLink to="/">
      <img src="../../../assets/images/logos/logo-dark.svg" />
    </RouterLink>
  </div>
</template>
<script setup lang="ts">
import { RouterLink } from "vue-router";
</script>
