<template>
    <div>
        <h3>찜한 동영상 목록</h3>
        <ul>
            <li v-for="(video, index) in favStore.favVideos">
                <p @click="goToVideo(video.videoID)">동영상ID : {{ video.videoID }}
                </p>
                <button @click="unfollow(video), hideBtn(index)">구독 취소하기</button>
                <div>
                    <iframe :src="`https://img.youtube.com/vi/${video.videoID}/0.jpg`"
                    width="400px" height="300px"></iframe>
                </div>
            </li>
        </ul>
    </div>
</template>

<script setup>
import { RouterLink } from 'vue-router'
import { ref, onMounted } from 'vue';
import { useFavoriteStore } from '../../stores/favorite';
import { useReviewStore } from '../../stores/review';
import router from '../../router';

const favStore = useFavoriteStore();
const reviewStore = useReviewStore()

const goToVideo = (id) => {
    reviewStore.videoID = id
    reviewStore.selectedYoutube = `https://www.youtube.com/embed/${id}`
    router.push('/review')
}

const unfollow = (video) => {
    favStore.setFavVideo(video)
}     

const hideBtn = (index) => {
    favStore.favVideos.splice(index, 1);
}


onMounted(() => {
    favStore.getFavVideos();
})



</script>

<style scoped></style>