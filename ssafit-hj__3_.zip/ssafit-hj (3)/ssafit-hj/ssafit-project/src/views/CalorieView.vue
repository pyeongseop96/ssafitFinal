<template>
    <div>
        미니헤더
        <RouterLink to="/calorie">다이어트 칼로리 계산</RouterLink> |
        <RouterLink to="/calorie/eat">음식 칼로리 계산</RouterLink>
    </div>
    <RouterView></RouterView>
</template>

<script setup>

</script>

<style scoped>

</style>